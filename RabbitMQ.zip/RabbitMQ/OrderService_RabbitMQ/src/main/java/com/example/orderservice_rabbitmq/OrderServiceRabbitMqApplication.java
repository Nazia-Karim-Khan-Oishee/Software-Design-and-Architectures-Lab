package com.example.orderservice_rabbitmq;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderServiceRabbitMqApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderServiceRabbitMqApplication.class, args);
	}

}
