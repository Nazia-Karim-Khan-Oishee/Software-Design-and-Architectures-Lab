package com.example.orderservice_rabbitmq;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderServiceRabbitMqApplicationTests {

	@Test
	void contextLoads() {
	}

}
