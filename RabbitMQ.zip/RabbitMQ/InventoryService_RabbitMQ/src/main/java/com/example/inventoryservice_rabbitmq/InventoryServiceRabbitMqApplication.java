package com.example.inventoryservice_rabbitmq;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InventoryServiceRabbitMqApplication {

	public static void main(String[] args) {
		SpringApplication.run(InventoryServiceRabbitMqApplication.class, args);
	}

}
