package com.example.inventoryservice_rabbitmq;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventoryServiceRabbitMqApplicationTests {

	@Test
	void contextLoads() {
	}

}
